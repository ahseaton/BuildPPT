﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace BuildPPT
{
    public partial class frmBuildPPT : Form
    {
        public frmBuildPPT()
        {
            InitializeComponent();
        }

        Dictionary<String, String[]> myDictionary = new Dictionary<string, String[]>()   // Dictionary with key as String & values as string arrays
            {
                { "test", new String[] { "Hood.jpg", "Monroe.jpg" } },       //Key is referred to search by user and value array contains the image names               
                { "only", new String[] { "Monroe.jpg", "Hood.png" } },
            };
        Boolean pic1Valid, pic2Valid;

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // Add Google Search API code here.  In the mean time, borrow Jane's

            String key = tbxTitle.Text;

            if (myDictionary.ContainsKey(key))                       //Checks if the entered key is in dictionary
            {
                String[] res = myDictionary[key];                    //Obtains the array of image names for that term  // Insert Google API Search here

                String firstPic = res[0];
                String secondPic = res[1];
                var outPutDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);   //This stores the path of the output directory of the project, here it is 'Debug' folder of this project
                var firstBox = Path.Combine(outPutDirectory, firstPic);                      // Now, firstBox has the relative path of the image existing in 'Image' folder which is pasted in 'Debug' folder
                var secondBox = Path.Combine(outPutDirectory, secondPic);
                String first_Box = new Uri(firstBox).LocalPath;
                String second_Box = new Uri(secondBox).LocalPath;
                pbxPic1.ImageLocation = first_Box;
                pic1Valid = true;
//                pbxPic2.ImageLocation = second_Box;
            }
            else
            {
                MessageBox.Show("Cannot find Image for this Title");                     //Message is displayed, if the term is not found in the key of dictionary
                pic1Valid = false;
            }

            String boxKey = rtxText.Text;                     // Insert Search for Bold here
            String key2 = boxKey.Replace("\n", "");           //replaces the new line character added to the term entered

            if (myDictionary.ContainsKey(key2))
            {

                String[] results = myDictionary[key2];

                String thirdPic = results[0];
                String fourthPic = results[1];
                var outPutDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);
                var thirdBox = Path.Combine(outPutDirectory, thirdPic);
                var fourthBox = Path.Combine(outPutDirectory, fourthPic);
                String third_Box = new Uri(thirdBox).LocalPath;
                String fourth_Box = new Uri(fourthBox).LocalPath;
                pbxPic2.ImageLocation = third_Box;
                pic2Valid = true;
                //                pictureBox4.ImageLocation = fourth_Box;

            }
            else
            {
                MessageBox.Show("Cannot find Image for this Text");
                pic2Valid = false;
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Add the save to PPTX code here.  I don't have the Office interface code loaded on my laptop, 
            // so I'm saving a generic XML file format from Linux
            //Note: There is an evil UTF8 code used to encode .pptx files even in Linux,
            //      So I haven't been able to reverse engineering the field names 
            //      in the time allowed, so this is a best guess without more details
            //Also Note: I am creating a "Sample.pptx" file, but PowerPoint 2013 (which is the only one I have) 
            //      errors on opening/converting it.  So, until the Magic UTF8 riddle is solved, Open With... NotePad

            // The using statement automatically flushes AND CLOSES the stream and calls 
            //      IDisposable.Dispose on the stream object.
            // Insert call to File Save As... to get directory and file name or somesuch
            // Tried to use outPutDirectory from above, but StreamWriter doesn't like URI filenames
            // Also tried checking and unchecking the cbx's but C# wasn't in the mood
            // Also Also tried to use pbxPic1/2.ImageLocation.Length > 0 and/or notnull, but C# put me out of the mood
            // Also Also Also don't even ask about enabling/disabling the check boxen based on whether a pic was found

            using (System.IO.StreamWriter file =
                new System.IO.StreamWriter(@"Sample.pptx"))  
            {
                file.WriteLine("<PPTX>");
                file.WriteLine("<Slide1>");

                file.WriteLine("<Title>" + tbxTitle.Text + "</Title>");
                file.WriteLine("<Text1>" + rtxText.Text + "</Text1>");

                // If the Pic1 checkbox is checked (and Pic was found), 
                //    write the pic box ImageLocation to the file as a mythical PicFileName tag
                if (cbxPic1.Checked && pic1Valid)
                {
                    file.WriteLine("<PicFileName>" + pbxPic1.ImageLocation + "</PicFileName>");
                }

                // If the Pic2 checkbox is checked and Pic2 was found,
                //    write the pic box ImageLocation to the file as a mythical PicFileName tag
                if (cbxPic2.Checked && pic2Valid)
                {
                    file.WriteLine("<PicFileName>" + pbxPic2.ImageLocation + "</PicFileName>");
                }

                file.WriteLine("</Slide1>");
                file.WriteLine("</PPTX>");
            }
        }
    }
}
