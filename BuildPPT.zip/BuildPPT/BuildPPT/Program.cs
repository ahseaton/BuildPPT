﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace BuildPPT
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 
        // Author:  Andrew Seaton (based on sample code from several sources)
        // For:     Coding sample for SEH America

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmBuildPPT());
        }
    }
}
