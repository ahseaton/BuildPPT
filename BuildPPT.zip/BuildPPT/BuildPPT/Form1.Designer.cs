﻿namespace BuildPPT
{
    partial class frmBuildPPT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblText = new System.Windows.Forms.Label();
            this.lblPics = new System.Windows.Forms.Label();
            this.tbxTitle = new System.Windows.Forms.TextBox();
            this.rtxText = new System.Windows.Forms.RichTextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.pbxPic1 = new System.Windows.Forms.PictureBox();
            this.pbxPic2 = new System.Windows.Forms.PictureBox();
            this.cbxPic1 = new System.Windows.Forms.CheckBox();
            this.cbxPic2 = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPic2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(16, 13);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(30, 13);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Title:";
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.Location = new System.Drawing.Point(16, 40);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(31, 13);
            this.lblText.TabIndex = 1;
            this.lblText.Text = "Text:";
            // 
            // lblPics
            // 
            this.lblPics.AutoSize = true;
            this.lblPics.Location = new System.Drawing.Point(16, 97);
            this.lblPics.Name = "lblPics";
            this.lblPics.Size = new System.Drawing.Size(30, 13);
            this.lblPics.TabIndex = 2;
            this.lblPics.Text = "Pics:";
            // 
            // tbxTitle
            // 
            this.tbxTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxTitle.Location = new System.Drawing.Point(53, 13);
            this.tbxTitle.Name = "tbxTitle";
            this.tbxTitle.Size = new System.Drawing.Size(219, 20);
            this.tbxTitle.TabIndex = 3;
            // 
            // rtxText
            // 
            this.rtxText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtxText.Location = new System.Drawing.Point(54, 40);
            this.rtxText.Name = "rtxText";
            this.rtxText.Size = new System.Drawing.Size(218, 50);
            this.rtxText.TabIndex = 4;
            this.rtxText.Text = "";
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.Location = new System.Drawing.Point(116, 229);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 6;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(197, 229);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pbxPic1
            // 
            this.pbxPic1.InitialImage = null;
            this.pbxPic1.Location = new System.Drawing.Point(54, 97);
            this.pbxPic1.Name = "pbxPic1";
            this.pbxPic1.Size = new System.Drawing.Size(100, 75);
            this.pbxPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxPic1.TabIndex = 8;
            this.pbxPic1.TabStop = false;
            // 
            // pbxPic2
            // 
            this.pbxPic2.InitialImage = null;
            this.pbxPic2.Location = new System.Drawing.Point(172, 96);
            this.pbxPic2.Name = "pbxPic2";
            this.pbxPic2.Size = new System.Drawing.Size(100, 75);
            this.pbxPic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxPic2.TabIndex = 9;
            this.pbxPic2.TabStop = false;
            // 
            // cbxPic1
            // 
            this.cbxPic1.AutoSize = true;
            this.cbxPic1.Location = new System.Drawing.Point(79, 178);
            this.cbxPic1.Name = "cbxPic1";
            this.cbxPic1.Size = new System.Drawing.Size(50, 17);
            this.cbxPic1.TabIndex = 10;
            this.cbxPic1.Text = "Pic 1";
            this.cbxPic1.UseVisualStyleBackColor = true;
            // 
            // cbxPic2
            // 
            this.cbxPic2.AutoSize = true;
            this.cbxPic2.Location = new System.Drawing.Point(197, 177);
            this.cbxPic2.Name = "cbxPic2";
            this.cbxPic2.Size = new System.Drawing.Size(50, 17);
            this.cbxPic2.TabIndex = 11;
            this.cbxPic2.Text = "Pic 2";
            this.cbxPic2.UseVisualStyleBackColor = true;
            // 
            // frmBuildPPT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.cbxPic2);
            this.Controls.Add(this.cbxPic1);
            this.Controls.Add(this.pbxPic2);
            this.Controls.Add(this.pbxPic1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.rtxText);
            this.Controls.Add(this.tbxTitle);
            this.Controls.Add(this.lblPics);
            this.Controls.Add(this.lblText);
            this.Controls.Add(this.lblTitle);
            this.Name = "frmBuildPPT";
            this.Text = "BuildPPT";
            ((System.ComponentModel.ISupportInitialize)(this.pbxPic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPic2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.Label lblPics;
        private System.Windows.Forms.TextBox tbxTitle;
        private System.Windows.Forms.RichTextBox rtxText;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.PictureBox pbxPic1;
        private System.Windows.Forms.PictureBox pbxPic2;
        private System.Windows.Forms.CheckBox cbxPic1;
        private System.Windows.Forms.CheckBox cbxPic2;
    }
}

